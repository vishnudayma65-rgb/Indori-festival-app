import { createRoot } from "react-dom/client";
import { createRootRoute, createRoute, createRouter, RouterProvider, Outlet } from "@tanstack/react-router";
import { FestivalWishes } from "@/components/festival-wishes";
import "@/styles.css";

const rootRoute = createRootRoute({ component: Outlet });
const indexRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/",
  component: FestivalWishes,
});
const router = createRouter({ routeTree: rootRoute.addChildren([indexRoute]) });
const element = document.getElementById("root");
if (element) createRoot(element).render(<RouterProvider router={router} />);