import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "node:path";

// Separate static entry; never ship TanStack Start's server output in a WebView.
export default defineConfig({
  root: path.resolve(import.meta.dirname),
  base: "./",
  plugins: [react(), tailwindcss()],
  resolve: { alias: { "@": path.resolve(import.meta.dirname, "../src") } },
  build: { outDir: "dist", emptyOutDir: true },
});