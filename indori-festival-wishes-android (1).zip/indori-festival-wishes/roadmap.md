# Tasks

- [x] Save the real AdMob App ID and banner ad unit ID in the app configuration.
- [x] Prepare a separate Capacitor Android project with package com.indori.festivalwishes and real AdMob configuration.
- [x] Confirm real AdMob IDs are configured for installed builds, as reiterated in the latest request.
- [x] Add native banner initialization with consent and safe test mode.
- [x] Provide downloadable source and signed AAB export steps in ANDROID-BUILD.md.
- [ ] Compile/sign APK or AAB — blocked: requires Android SDK and the user's private upload signing key; this request is for preparation and export instructions.