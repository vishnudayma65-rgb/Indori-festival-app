import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.indori.festivalwishes",
  appName: "Indori Festival Wishes",
  webDir: "mobile/dist",
};

export default config;