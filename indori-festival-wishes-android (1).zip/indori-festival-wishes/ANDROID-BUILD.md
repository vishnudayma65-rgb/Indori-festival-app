# Indori Festival Wishes — Android / Play Store

## Prepared configuration

- Application ID / package: `com.indori.festivalwishes` (Android package names cannot include `http://`).
- AdMob App ID: `ca-app-pub-2236172312981530~4294379829` (ASCII `~`, not Unicode `∼`).
- Banner unit: `ca-app-pub-2236172312981530/8888230957`.
- Version: `1.0`, version code `1`.
- Minimum Android SDK: 24; compile/target SDK: 36.
- Capacitor 8.5.3; AdMob plugin 8.2.1.

The Android project is in `android/`. Its web screen is bundled locally from `mobile/`, shares the same festival screen/photos/wishes as the web app, and does not depend on a published website or a preview URL. The existing TanStack Start web app remains unchanged in framework and routing.

**This download is source, not a compiled or signed AAB/APK.** Android compilation, signing, physical-device testing, and Google Play approval have not been completed here.

## 1. Install tools on your computer

1. Install a current Android Studio that supports Android Gradle Plugin 8.13, and install Android SDK Platform 36 / Build Tools through its SDK Manager.
2. Use JDK 21 for Gradle (Android Studio → Settings → Build Tools → Gradle → Gradle JDK).
3. Install Node.js 22 or newer and Bun. Capacitor CLI requires Node 22+.
4. Extract the source ZIP and open a terminal in its top-level folder.

## 2. Prepare and test the Android project

```sh
bun install --frozen-lockfile
bun run android:prepare
bun run android:open
```

`android:prepare` synchronizes the App ID from `src/lib/admob.ts` into the Android manifest, builds the separate static mobile screen into `mobile/dist`, and runs Capacitor sync. Do not copy the TanStack Start server build into Android. Run this command again after any screen, photo, wish, plugin, or ad-setting change.

In Android Studio, allow Gradle sync and required SDK downloads. Select a connected Android phone or emulator, then click Run. Test all three categories, Copy, Share, image saving, and scrolling. Native Share opens Android's share chooser; select WhatsApp. Download Image opens the image share/save chooser; choose an available Files or image-saving destination. It does not automatically write to the phone's gallery.

## 3. AdMob setup and consent

1. In your AdMob account, confirm the app and banner unit belong to this Android app.
2. Configure and publish your applicable consent messages under AdMob **Privacy & messaging**. The app refreshes UMP consent information on launch, shows a required consent form, and requests ads only when UMP reports `canRequestAds`.
3. Where required, the app exposes **Ad privacy choices** to reopen the UMP privacy-options form.
4. The web preview still uses placeholders after every two wishes. Android uses one native 320×50 bottom banner while an every-two-wishes marker is visible. This plugin does not render multiple inline banners inside the scrolling web cards. Space is reserved at the bottom to keep buttons clear of the banner.
5. Test ads are **enabled by default even for production web-asset builds**, to prevent accidental live-ad traffic during development. Test consent/privacy choices and ad behavior on physical devices. Never click your own live ads.

For the final live-ad bundle only, build using this command on macOS/Linux:

```sh
VITE_ADMOB_LIVE_ADS=true bun run android:prepare
```

Windows PowerShell:

```powershell
$env:VITE_ADMOB_LIVE_ADS = "true"
bun run android:prepare
Remove-Item Env:VITE_ADMOB_LIVE_ADS
```

For normal device development/testing, omit this setting so test mode stays enabled. The real IDs remain configured in both modes. Consent/network failures suppress ads rather than blocking the wishes. Real ad serving depends on account/app eligibility, consent, inventory, and Google approval; it is not guaranteed by entering the IDs.

## 4. Export the signed AAB

1. In Android Studio open the `android/` folder if it is not already open.
2. Check `android/app/build.gradle`: application ID `com.indori.festivalwishes`, `versionCode 1`, `versionName "1.0"`. Increase version code for every subsequent Play upload.
3. Select **Build → Generate Signed App Bundle or APK** (wording varies slightly by Studio version).
4. Select **Android App Bundle**, then **Next**.
5. Select your existing upload keystore, or click **Create new** to create an upload key. Store it outside the source folder. Keep a secure backup of the key, alias, and passwords. Do not send passwords or keys in chat or commit them to source control.
6. Select module **app**, choose the **release** variant, and complete the wizard.
7. Use Android Studio's **Locate** link to find the generated `.aab`. It is commonly `android/app/release/app-release.aab` or `android/app/build/outputs/bundle/release/app-release.aab`, depending on the wizard's destination.
8. Upload the signed bundle to a Play Console **Internal testing** release first. Use Play App Signing and your upload key; do not confuse an unsigned Gradle bundle with a store-ready signed bundle.

An AAB is not installed directly on a phone; test through Play's internal testing track or build a debug APK with Android Studio for local development. Signing and Play Console upload are intentionally left to you; no private upload key is included.

## 5. Before a production Play release

- Replace the default Capacitor launcher icon in Android Studio's Image Asset tool and prepare a 512×512 Play icon, 1024×500 feature graphic, screenshots, and store listing.
- Supply a real public privacy-policy URL. Include Google Mobile Ads data handling and your actual app practices, and declare **Contains ads** / complete **Data safety** accurately. No privacy policy has been invented for you.
- Complete content rating, target audience, app access, and other current Play Console declarations. If children are in the target audience, review Families rules and configure age-appropriate ad treatment before release; this template does not determine your audience.
- Complete any testing and identity-verification requirements that apply to your developer account. Check current target-API and policy deadlines in Play Console at submission time.
- Configure app-ads.txt on your developer website if AdMob requests it; use AdMob's exact provided publisher line, not a guessed value.
- Test consent in applicable regions, denied consent, privacy-choice changes, ad failures, sharing to WhatsApp, and image saving on actual devices.
- Review photo licensing and your wish content before publishing. Source preparation is not a guarantee of Play Store acceptance.

## Reference

- Capacitor: https://capacitorjs.com/docs/android
- AdMob plugin: https://github.com/capacitor-community/admob
- UMP privacy: https://developers.google.com/admob/android/privacy
- App signing: https://developer.android.com/studio/publish/app-signing