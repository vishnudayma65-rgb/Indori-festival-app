import { readFileSync, writeFileSync } from "node:fs";
import { ADMOB } from "../src/lib/admob";

const path = "android/app/src/main/AndroidManifest.xml";
const source = readFileSync(path, "utf8");
const entry = `<meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="${ADMOB.appId}" />`;
const updated = source.includes("com.google.android.gms.ads.APPLICATION_ID")
  ? source.replace(/<meta-data\s+android:name="com\.google\.android\.gms\.ads\.APPLICATION_ID"[^>]*\/>/, entry)
  : source.replace("        <activity", `        ${entry}\n\n        <activity`);
writeFileSync(path, updated);
console.log("Android AdMob App ID synchronized.");