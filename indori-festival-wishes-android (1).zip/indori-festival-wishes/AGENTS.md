<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep AdMob identifiers centralized in `src/lib/admob.ts`; the web UI renders placeholders, native ads use `src/lib/native-ads.ts`, and `scripts/configure-android.ts` synchronizes the native manifest.
- Share the festival screen between the TanStack Start route and a separate static TanStack Router entry under `mobile/`; Capacitor bundles `mobile/dist` without a remote server URL because Start's server output is not Android web assets.
- Default native ads to testing until explicitly enabled for release, and gate all ad requests on UMP consent eligibility to prevent unsafe development traffic.
