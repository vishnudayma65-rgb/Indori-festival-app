import { Fragment, useState, useEffect, useRef } from "react";
import { Copy, Download, Share2 } from "lucide-react";
import diwaliImg from "@/assets/diwali.jpg";
import holiImg from "@/assets/holi.jpg";
import eidImg from "@/assets/eid.jpg";
import { WISHES, type Festival } from "@/lib/wishes";
import { ADMOB } from "@/lib/admob";

import { Button } from "@/components/ui/button";
import { copyWish, shareWish, saveWishImage } from "@/lib/wish-actions";
import { prepareNativeAds } from "@/lib/native-ads";

const TABS: { id: Festival; label: string; img: string }[] = [
  { id: "diwali", label: "🪔 Diwali", img: diwaliImg },
  { id: "holi", label: "🎨 Holi", img: holiImg },
  { id: "eid", label: "🌙 Eid", img: eidImg },
];

async function downloadWish(text: string, img: string, idx: number) {
  const image = new Image();
  image.src = img;
  await image.decode();
  const W = 1080, H = 1350;
  const c = document.createElement("canvas");
  c.width = W; c.height = H;
  const ctx = c.getContext("2d");
  if (!ctx) throw new Error("Image creation is unavailable");
  ctx.fillStyle = "#FFFFFF";
  ctx.fillRect(0, 0, W, H);
  ctx.drawImage(image, 0, 0, W, 675);
  ctx.fillStyle = "#FF6A00";
  ctx.font = "bold 52px sans-serif";
  ctx.textAlign = "center";
  const words = text.split(" ");
  let line = "", y = 820;
  for (const w of words) {
    const t = line + w + " ";
    if (ctx.measureText(t).width > W - 120 && line) {
      ctx.fillText(line, W / 2, y); line = w + " "; y += 70;
    } else line = t;
  }
  ctx.fillText(line, W / 2, y);
  ctx.font = "32px sans-serif";
  ctx.fillText("— Indori Festival Wishes", W / 2, H - 60);
  await saveWishImage(c.toDataURL("image/png"), `wish-${idx + 1}.png`);
}

function AdBanner() {
  return (
    <div className="ad-slot" aria-label="Advertisement" data-admob-app-id={ADMOB.appId} data-admob-ad-unit-id={ADMOB.bannerAdUnitId}>
      <span className="text-[10px] uppercase tracking-wider opacity-60">Ad</span>
      <span className="text-sm">AdMob Banner 320×50</span>
      <span className="text-[10px] opacity-60">{ADMOB.bannerAdUnitId}</span>
    </div>
  );
}

export function FestivalWishes() {
  const [tab, setTab] = useState<Festival>("diwali");
  const [copied, setCopied] = useState<number | null>(null);
  const current = TABS.find((t) => t.id === tab) ?? TABS[0];
  if (!current) return null;
  const list = WISHES[tab];
  const [native, setNative] = useState(false);
  const [adsReady, setAdsReady] = useState(false);
  const [privacyRequired, setPrivacyRequired] = useState(false);
  const [actionError, setActionError] = useState("");
  const ads = useRef<Awaited<ReturnType<typeof prepareNativeAds>>>(null);
  const mainRef = useRef<HTMLElement>(null);

  useEffect(() => {
    let disposed = false;
    void import("@capacitor/core").then(({ Capacitor }) => {
      if (!Capacitor.isNativePlatform()) return;
      setNative(true);
      return prepareNativeAds().then((session) => {
        if (disposed) return;
        ads.current = session;
        setAdsReady(true);
        setPrivacyRequired(session?.privacyRequired ?? false);
      });
    }).catch(() => { /* Consent/network failures must not request ads. */ });
    return () => { disposed = true; void ads.current?.hide(); };
  }, []);

  useEffect(() => {
    if (!native || !mainRef.current) return;
    let shown = false;
    const visibleSlots = new Set<Element>();
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) visibleSlots.add(entry.target);
        else visibleSlots.delete(entry.target);
      });
      const visible = visibleSlots.size > 0;
      if (visible === shown) return;
      shown = visible;
      const operation = visible ? ads.current?.show() : ads.current?.hide();
      void operation?.catch(() => {});
    }, { threshold: 0.1 });
    mainRef.current.querySelectorAll('[data-ad-slot]').forEach((slot) => observer.observe(slot));
    return () => { observer.disconnect(); void ads.current?.hide(); };
  }, [native, tab, adsReady]);

  async function action(work: () => Promise<void>) {
    setActionError("");
    try { await work(); } catch { setActionError("Unable to complete this action. Please try again."); }
  }

  return (
    <div className="min-h-screen bg-background pb-24 pt-[env(safe-area-inset-top)]">
      <header className="sticky top-0 z-10 bg-primary text-primary-foreground shadow-md">
        <h1 className="px-4 pt-4 pb-3 text-center text-xl font-extrabold tracking-wide">
          Indori Festival Wishes
        </h1>
        <nav className="grid grid-cols-3 gap-2 px-3 pb-3">
          {TABS.map((t) => (
            <Button
              variant="ghost"
              key={t.id}
              onClick={() => { setTab(t.id); setCopied(null); window.scrollTo({ top: 0 }); }}
              className={`rounded-full py-2 text-sm font-bold transition ${
                tab === t.id ? "bg-primary-foreground text-primary" : "bg-primary-foreground/15"
              }`}
            >
              {t.label}
            </Button>
          ))}
        </nav>
      </header>

      {privacyRequired && <div className="mx-auto max-w-md px-3 pt-3"><Button variant="outline" onClick={() => action(async () => { await ads.current?.privacy(); })}>Ad privacy choices</Button></div>}
      {actionError && <p role="alert" className="mx-auto max-w-md px-3 pt-3 text-destructive">{actionError}</p>}
      <main ref={mainRef} className="mx-auto max-w-md space-y-4 px-3 pt-4">
        {list.map((wish, i) => (
          <Fragment key={tab + i}>
            <article className="overflow-hidden rounded-2xl border border-primary/20 bg-card shadow-sm">
              <p className="p-4 text-base font-medium leading-relaxed text-foreground">{wish}</p>
              <img src={current.img} alt={`${tab} festival`} loading="lazy" className="aspect-[16/10] w-full object-cover" />
              <div className="grid grid-cols-2 gap-2 p-3">
                <Button
                  onClick={() => action(() => shareWish(wish))}
                  className="flex h-auto items-center justify-center gap-2 rounded-xl bg-primary py-2.5 text-sm font-bold text-primary-foreground"
                >
                  <Share2 size={16} /> Share
                </Button>
                <Button
                  variant="outline" onClick={() => action(async () => { await copyWish(wish); setCopied(i); setTimeout(() => setCopied(null), 1500); })}
                  className="flex items-center justify-center gap-2 rounded-xl border-2 border-primary py-2.5 text-sm font-bold text-primary"
                >
                  <Copy size={16} /> {copied === i ? "Copied!" : "Copy"}
                </Button>
                <Button
                  variant="secondary" onClick={() => action(() => downloadWish(wish, current.img, i))}
                  className="col-span-2 flex items-center justify-center gap-2 rounded-xl bg-primary/10 py-2.5 text-sm font-bold text-primary"
                >
                  <Download size={16} /> Download Image
                </Button>
              </div>
            </article>
            {i % 2 === 1 && (native ? <div data-ad-slot className="h-[70px]" aria-hidden="true" /> : <AdBanner />)}
          </Fragment>
        ))}
      </main>
    </div>
  );
}
