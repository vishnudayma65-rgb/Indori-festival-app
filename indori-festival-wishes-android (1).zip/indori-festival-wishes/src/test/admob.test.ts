import { describe, expect, it } from "vitest";
import { ADMOB } from "../lib/admob";
import { canLoadAds, nativeBannerOptions, useTestAds } from "../lib/native-ads";
import { readFileSync } from "node:fs";

describe("user AdMob configuration", () => {
  it("uses the real App ID with the standard ASCII separator", () => {
    expect(ADMOB.appId).toBe("ca-app-pub-2236172312981530~4294379829");
  });

  it("uses the real banner ad unit", () => {
    expect(ADMOB.bannerAdUnitId).toBe("ca-app-pub-2236172312981530/8888230957");
  });

  it("does not request ads without consent eligibility", () => {
    expect(canLoadAds({ canRequestAds: false })).toBe(false);
    expect(canLoadAds({ canRequestAds: true })).toBe(true);
  });
  it("uses test ads unless live ads are explicitly enabled", () => {
    expect(useTestAds(undefined)).toBe(true);
    expect(useTestAds("false")).toBe(true);
    expect(useTestAds("true")).toBe(false);
    expect(nativeBannerOptions(true)).toEqual({ adId: "ca-app-pub-2236172312981530/8888230957", isTesting: true });
  });
  it("sets the requested Android application ID", () => {
    expect(readFileSync("android/app/build.gradle", "utf8")).toContain('applicationId "com.indori.festivalwishes"');
  });
  it("configures the native SDK with the real App ID", () => {
    expect(readFileSync("android/app/src/main/AndroidManifest.xml", "utf8")).toContain('android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="ca-app-pub-2236172312981530~4294379829"');
  });
});