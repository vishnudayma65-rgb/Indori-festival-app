import { createFileRoute } from "@tanstack/react-router";
import { FestivalWishes } from "@/components/festival-wishes";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Indori Festival Wishes — Diwali, Holi & Eid" },
      { name: "description", content: "100 beautiful Diwali, Holi and Eid wishes to share on WhatsApp, copy or download as image." },
      { property: "og:title", content: "Indori Festival Wishes" },
      { property: "og:description", content: "Share Diwali, Holi and Eid wishes on WhatsApp." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: FestivalWishes,
});

