export type Festival = "diwali" | "holi" | "eid";

const diwaliBase = [
  "May the light of diyas fill your home with happiness and prosperity.",
  "Wishing you a Diwali full of sweets, smiles and sparkling moments.",
  "May Goddess Lakshmi bless you with wealth and good health.",
  "Let this Diwali burn away all your worries. Happy Diwali!",
  "From Indore with love — wishing you a dazzling Diwali!",
  "May your life shine as bright as a thousand diyas.",
  "Light up your dreams this Diwali and let them glow forever.",
  "Rangoli colours, diya lights, and family love — Happy Diwali!",
  "May this festival of lights bring new beginnings for you.",
  "Wishing you peace, joy and poha-jalebi mornings this Diwali!",
  "Let every diya you light bring a smile to someone's face.",
];
const holiBase = [
  "May your life be as colourful as Holi. Happy Holi!",
  "Bura na mano, Holi hai! Wishing you a rang-bhari Holi.",
  "Splash the colours of love and laughter this Holi.",
  "May the colours of Holi fill your life with joy.",
  "Gulal ki khushboo, pichkari ki dhaar — Happy Holi from Indore!",
  "Forget the worries, grab the colours — it's Holi!",
  "Wishing you a Holi full of gujiya, thandai and friends.",
  "Let's paint the town in colours of happiness. Happy Holi!",
  "May this Holi wash away sorrows and bring new hope.",
  "Red for love, yellow for joy, green for peace — Happy Holi!",
  "Celebrate the victory of good over evil with bright colours.",
];
const eidBase = [
  "Eid Mubarak! May Allah bless you with happiness and peace.",
  "May the crescent moon bring light and joy to your home.",
  "Wishing you and your family a blessed Eid full of love.",
  "May your prayers be answered and your heart be full. Eid Mubarak!",
  "Sheer khurma, hugs and blessings — Eid Mubarak from Indore!",
  "May this Eid bring endless smiles and countless blessings.",
  "Let us celebrate Eid with gratitude, kindness and love.",
  "May Allah shower His mercy on you this Eid.",
  "Chand raat ki roshni aapki zindagi roshan kare. Eid Mubarak!",
  "Wishing you peace, prosperity and togetherness this Eid.",
  "May the spirit of Eid stay with you all year long.",
];

const endings = ["", " 🪔✨", " 💛", " 🙏"];
const holiEnd = ["", " 🎨🌈", " 💖", " 🎉"];
const eidEnd = ["", " 🌙✨", " 🤲", " 💚"];

function build(base: string[], ends: string[], count: number) {
  const out: string[] = [];
  for (let i = 0; i < count; i++) {
    out.push((base[i % base.length] ?? "") + (ends[Math.floor(i / base.length) % ends.length] ?? ""));
  }
  return out;
}

export const WISHES: Record<Festival, string[]> = {
  diwali: build(diwaliBase, endings, 34),
  holi: build(holiBase, holiEnd, 33),
  eid: build(eidBase, eidEnd, 33),
};
