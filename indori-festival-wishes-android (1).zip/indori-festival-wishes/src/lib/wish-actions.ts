export async function copyWish(text: string) {
  const { Capacitor } = await import("@capacitor/core");
  if (Capacitor.isNativePlatform()) {
    const { Clipboard } = await import("@capacitor/clipboard");
    await Clipboard.write({ string: text });
    return;
  }
  await navigator.clipboard.writeText(text);
}

export async function shareWish(text: string) {
  const { Capacitor } = await import("@capacitor/core");
  if (Capacitor.isNativePlatform()) {
    const { Share } = await import("@capacitor/share");
    await Share.share({ text, title: "Indori Festival Wishes" });
    return;
  }
  window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank", "noopener,noreferrer");
}

export async function saveWishImage(dataUrl: string, name: string) {
  const { Capacitor } = await import("@capacitor/core");
  if (Capacitor.isNativePlatform()) {
    const { Filesystem, Directory } = await import("@capacitor/filesystem");
    const { Share } = await import("@capacitor/share");
    const result = await Filesystem.writeFile({
      path: name,
      data: dataUrl.split(",")[1] ?? "",
      directory: Directory.Cache,
    });
    await Share.share({ title: "Save festival wish", files: [result.uri] });
    return;
  }
  const link = document.createElement("a");
  link.href = dataUrl;
  link.download = name;
  link.click();
}