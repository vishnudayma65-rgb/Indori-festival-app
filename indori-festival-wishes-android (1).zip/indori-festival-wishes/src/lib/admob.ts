// Native Android builds must also configure this App ID in AndroidManifest.xml.
// These values do not initialize native AdMob in the web preview.
export const ADMOB = {
  appId: "ca-app-pub-2236172312981530~4294379829",
  bannerAdUnitId: "ca-app-pub-2236172312981530/8888230957",
} as const;