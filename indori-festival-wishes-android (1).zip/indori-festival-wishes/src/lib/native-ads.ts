import { ADMOB } from "./admob";

export function canLoadAds(info: { canRequestAds: boolean }): boolean {
  return info.canRequestAds === true;
}

export function nativeBannerOptions(testing: boolean) {
  return { adId: ADMOB.bannerAdUnitId, isTesting: testing };
}

export function useTestAds(liveAds: string | undefined) { return liveAds !== "true"; }

export async function prepareNativeAds() {
  const { Capacitor } = await import("@capacitor/core");
  if (!Capacitor.isNativePlatform()) return null;
  const { AdMob, AdmobConsentStatus } = await import("@capacitor-community/admob");
  let info = await AdMob.requestConsentInfo();
  if (info.isConsentFormAvailable && info.status === AdmobConsentStatus.REQUIRED) {
    info = await AdMob.showConsentForm();
  }
  // Default to test ads, including production builds, until explicitly enabled.
  const testing = useTestAds(import.meta.env['VITE_ADMOB_LIVE_ADS']);
  if (canLoadAds(info)) await AdMob.initialize({ initializeForTesting: testing });
  return {
    eligible: canLoadAds(info),
    privacyRequired: info.privacyOptionsRequirementStatus === "REQUIRED",
    async show() {
      if (!canLoadAds(info)) return;
      const { BannerAdSize, BannerAdPosition } = await import("@capacitor-community/admob");
      await AdMob.showBanner({
        ...nativeBannerOptions(testing),
        adSize: BannerAdSize.BANNER,
        position: BannerAdPosition.BOTTOM_CENTER,
      });
    },
    async hide() { await AdMob.hideBanner(); },
    async privacy() {
      info = { ...info, canRequestAds: false };
      await AdMob.removeBanner();
      await AdMob.showPrivacyOptionsForm();
      info = await AdMob.requestConsentInfo();
      if (canLoadAds(info)) await AdMob.initialize({ initializeForTesting: testing });
    },
  };
}