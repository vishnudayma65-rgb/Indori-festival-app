package com.indori.festivalwishes;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
